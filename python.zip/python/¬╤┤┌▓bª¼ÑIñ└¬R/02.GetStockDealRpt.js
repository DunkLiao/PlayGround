﻿/*
'*************************************************************************************
'專案名稱: 全權委託
'功能描述: 讀取投資商品交易日報表股票交易
'
'版權所有: 台灣銀行
'程式撰寫: Dunk
'撰寫日期：2020/2/26
'
'改版日期:
'改版備註:
'
'
'*************************************************************************************
 */

//程式進入點
Main();

function Main() {
	iimPlay("DisSystem/01.LoginDisSystem.iim");

	GetAMRPT01100Rpt();
}

//取得報表資料
function GetAMRPT01100Rpt() {
	var valueDate = window.prompt("要查詢的日期(yyyy/mm/dd)：");
	if (valueDate == "") {
		valueDate = GetToday();
	}
	DoAMRPT01100(valueDate);
}

//取得存檔資料夾
function GetFolder() {
	return "D:\\"
}

//取得存檔檔案名稱
function GetSaveFileName() {
	return "股款報表.xls"
}

//取當日
function GetToday() {
	//取當日
	var enddate = new Date();
	return SetDateformat(enddate);
}

//設定日期格式(yyyy/mm/dd)
function SetDateformat(Date) {
	var Y = Date.getFullYear();
	var M = Date.getMonth() + 1;
	M = M < 10 ? '0' + M : M;
	var D = Date.getDate();
	D = D < 10 ? '0' + D : D;
	return Y + '/' + M + '/' + D
}

//設定基金功能代號
function SetFuncNo(prgid) {
	var macro;
	macro = "CODE:";
	macro += "TAG POS=1 TYPE=INPUT:TEXT ATTR=ID:findProgId CONTENT=" + prgid + "\n";
	macro += "TAG POS=1 TYPE=BUTTON ATTR=ID:findProgBtn" + "\n";
	iimPlay(macro);
}

//下載投資商品交易日報表
function DoAMRPT01100(queryDate) {
	SetFuncNo("AMRPT01100");
	var macro;
	macro = "CODE:";
	macro += "FRAME NAME=\"mainPanel\"" + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:rpt01100 ATTR=ID:dealDateStr CONTENT=" + queryDate + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:rpt01100 ATTR=ID:dealDateEnd CONTENT=" + queryDate + "\n";
	macro += "TAG POS=1 TYPE=SELECT FORM=ID:rpt01100 ATTR=ID:rptType CONTENT=%xls" + "\n";
	macro += "TAG POS=1 TYPE=INPUT:CHECKBOX FORM=ID:rpt01100 ATTR=ID:chkStk CONTENT=YES" + "\n";
	macro += "ONDOWNLOAD FOLDER=" + GetFolder() + " FILE=" + GetSaveFileName() + " WAIT=YES" + "\n";
	macro += "TAG POS=1 TYPE=BUTTON FORM=ID:rpt01100 ATTR=ID:btnRpt" + "\n";
	iimPlay(macro);
}
