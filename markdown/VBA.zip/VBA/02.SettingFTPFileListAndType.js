﻿/*
'*************************************************************************************
'專案名稱: 全權委託
'功能描述: 設定傳輸電子檔代碼(第二層)及檔案名稱
'AMMET10004  手動上傳檔案至待處理區－從固定IP(全委契約資料)
'版權所有: 台灣銀行
'程式撰寫: Dunk
'撰寫日期：2018/7/27
'
'改版日期:
'改版備註:
'
'
'*************************************************************************************
 */

//程式進入點
Main();
function Main() {
	var funcno = window.prompt("設定傳輸電子檔清單及檔案種類，不設定按確定(1.股票及期貨，2.短票及定存)：");
	var fileType,
	trList

	switch (funcno) {
	case "1":
		//股票及期貨
		fileType = "SKT,FUC,FUT"
			break;
	case "2":
		//短票及定存
		fileType = "SBT,TDT"
			break;
	default:
		fileType = "SKT,FUC,FUT,SBT,TDT"
	}
	//傳輸清單
	trList = "002H,9831,9832,9771,04C1,04C2,04C3,0217,0218,01A4,0105,0106";
	//trList = "002H,961F,9771,9929,0711,0712,0713,0714,0715,0716,0717,0217,0218,9831,9832,01E1,01A4,0019,0431,0432,0433,04C1,04C2,04C3,02D1,02D2";
	funcno = window.prompt("設定代理，不設定按確定(1.秉志，2.振富，3.蘭錦)：");
	switch (funcno) {
	case "1":
		//秉志
		trList = trList + ",0321,0322,0323,0324,0325"
			break;
	case "2":
		//振富
		trList = trList + ",0711,0712,0713,0714,0715,0716,0717,0019"
			break;
	case "3":
		//蘭錦
		trList = trList + ",06A1,06A2,06A3,06A4,06A5,06A6,06A7"
			break;
	}
	//設定
	SetTransposeAndFileType(trList, fileType);
}

//傳輸電子檔代碼(第二層)及檔案名稱
function SetTransposeAndFileType(trList, fileType) {
	var macro;
	macro = "CODE:";
	macro += "FRAME NAME=\"mainPanel\"" + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:frmMet10004 ATTR=ID:eFileCde CONTENT=" + trList + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:frmMet10004 ATTR=ID:fileNam CONTENT=" + fileType + "\n";
	iimPlay(macro)
}
