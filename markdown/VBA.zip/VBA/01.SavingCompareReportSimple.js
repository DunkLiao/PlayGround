﻿/*
'*************************************************************************************
'專案名稱: 全權委託
'功能描述: 存檔比對報表_簡單版
'
'版權所有: 台灣銀行
'程式撰寫: Dunk
'撰寫日期：2021/2/1
'
'改版日期:
'改版備註:
'
'
'
'*************************************************************************************
 */

//程式進入點
Main();

function Main() {
	var disNo = window.prompt("設定每日比對報表，請輸入基金編號(BXXXX BXXXX)，不設定按確定進入初始設定：");
	if (disNo == '') {
		initialPage();
	} else {
		var ss = disNo.split(" ");
		QueryDailyRptByFundNo(ss[0], ss[1]);
	}

}

//初始設定畫面
function initialPage() {
	iimPlay("DisSystem/01.LoginDisSystem.iim");

	//(對外報表)資產負債報告書(R>20>倒數2)
	SetFuncNo("AMRPT23110");
	SetBsReport();

	//(對外報表)損益報告書(R>20>倒數1)
	OpenTabAndLogin(2);
	SetFuncNo("AMRPT23120");

	//定存利息調整處理(A>03>5)
	OpenTabAndLogin(2);
	SetFuncNo("AMACT02003");

}

//取得存檔資料夾
function GetFolder() {
	return "D:\\"
}

//取得存檔檔案名稱
function GetSaveFileName(medtype) {
	if (medtype == "BS") {
		return "全委對帳BS.xls"
	} else {
		return "全委對帳IS.xls"
	}

}

//根據基金編號查詢每日報表(資產負債表及損益表)
function QueryDailyRptByFundNo(disNoStart, disNoEnd) {
	var macro;
	macro = "CODE:";
	macro += "SET !ERRORIGNORE YES" + "\n";;
	macro += "TAB T=1" + "\n";
	macro += "FRAME NAME=\"mainPanel\"" + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:frmRpt23110 ATTR=ID:contrNoStr CONTENT=" + disNoStart + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:frmRpt23110 ATTR=ID:contrNoEnd CONTENT=" + disNoEnd + "\n";
	macro += "TAG POS=1 TYPE=SELECT FORM=ID:frmRpt23110 ATTR=ID:rptType CONTENT=%xls" + "\n";
	macro += "ONDOWNLOAD FOLDER=" + GetFolder() + " FILE=" + GetSaveFileName("BS") + " WAIT=YES" + "\n";
	macro += "TAG POS=1 TYPE=BUTTON FORM=ID:frmRpt23110 ATTR=ID:btnRpt" + "\n";
	macro += "TAB T=2" + "\n";
	macro += "FRAME NAME=\"mainPanel\"" + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:frmRpt23120 ATTR=ID:contrNoStr CONTENT=" + disNoStart + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:frmRpt23120 ATTR=ID:contrNoEnd CONTENT=" + disNoEnd + "\n";
	macro += "TAG POS=1 TYPE=SELECT FORM=ID:frmRpt23120 ATTR=ID:rptType CONTENT=%xls" + "\n";
	macro += "ONDOWNLOAD FOLDER=" + GetFolder() + " FILE=" + GetSaveFileName("IS") + " WAIT=YES" + "\n";
	macro += "TAG POS=1 TYPE=BUTTON FORM=ID:frmRpt23120 ATTR=ID:btnRpt" + "\n";
	iimPlay(macro);
}

//開啟頁籤並登入
function OpenTabAndLogin(tabNum) {
	OpeTabs(tabNum);
	iimPlay("DisSystem/01.LoginDisSystem.iim");
}

//開啟新頁籤
function OpeTabs(tabNum) {
	var macro;
	macro = "CODE:";
	macro += "TAB OPEN" + "\n";
	macro += "TAB T=" + tabNum + "\n";
	iimPlay(macro);
}

//設定基金功能代號
function SetFuncNo(prgid) {
	var macro;
	macro = "CODE:";
	macro += "TAG POS=1 TYPE=INPUT:TEXT ATTR=ID:findProgId CONTENT=" + prgid + "\n";
	macro += "TAG POS=1 TYPE=BUTTON ATTR=ID:findProgBtn" + "\n";
	iimPlay(macro)
}

//設定資產負債表
function SetBsReport() {
	var macro;
	macro = "CODE:";
	macro += "FRAME NAME=\"mainPanel\"" + "\n";
	macro += "TAG POS=1 TYPE=SELECT FORM=ID:frmRpt23110 ATTR=ID:reportSelect CONTENT=%01" + "\n";
	macro += "TAG POS=1 TYPE=SELECT FORM=ID:frmRpt23110 ATTR=ID:printRange CONTENT=%1" + "\n";
	iimPlay(macro)
}

//設定淨值評算處理*處理範圍：1-應收付計算*
function SetNetCalc() {
	var macro;
	macro = "CODE:";
	macro += "FRAME NAME=\"mainPanel\"" + "\n";
	macro += "TAG POS=1 TYPE=SELECT FORM=ID:frmAct01100 ATTR=ID:prcsRange CONTENT=%1" + "\n";
	iimPlay(macro)
}
