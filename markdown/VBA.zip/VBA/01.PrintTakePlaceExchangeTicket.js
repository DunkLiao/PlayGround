﻿/*
'*************************************************************************************
'專案名稱: 期信基金
'功能描述: 設定存取匯匯款單
'https://stackoverflow.com/questions/29586878/put-csv-data-to-array-imacros-js
'版權所有: 台灣銀行
'程式撰寫: Dunk
'撰寫日期：2021/1/27
'
'改版日期:
'改版備註: 2021/2/2 增加彈跳等待
'          2021/2/4 增加送金簿設定
'*************************************************************************************
 */

Main()

//程式進入點
function Main() {
	//登入系統
	iimPlay("FundSystem/01.LoginFundSystem.iim");
	//匯款日期設定
	var valuedate = window.prompt("請輸入交割日期(yyyy/mm/dd)：");
	if (valuedate == "") {
		valuedate = GetToday();
	}
	//身份號
	persionid = window.prompt("請輸入身份證號：");

	//存款條是否為送金簿
	isSendType = window.prompt("存款條是否為送金簿(Y/N，預設為N)：");
	if (isSendType == "") {
		isSendType = "N";
	}

	//存款條是否為送金簿
	printType = window.prompt("是否包含存匯款(1:存,2:匯,3存+匯；預設3)：");
	if (printType == "") {
		printType = 3;
	}

	//取款
	SetFuncNo("AMMET29020");
	SetAMMET29020Init("01");
	ReadTaDataFromCsv("D:\\取款設定.csv", valuedate);
	WaitPop();

	//存款
	if (printType == 3 || printType == 1) {
		OpenTabAndLogin(2);
		SetFuncNo("AMMET29020");
		SetAMMET29020Init("03");
		ReadSaDataFromCsv("D:\\存款設定.csv", valuedate, isSendType);
		WaitPop();
	}

	//匯款
	if (printType == 3 || printType == 2) {
		OpenTabAndLogin(2);
		SetFuncNo("AMMET29020");
		SetAMMET29020Init("02");
		ReadExDataFromCsv("D:\\匯款設定.csv", valuedate, persionid);
	}
}

//開啟頁籤並登入
function OpenTabAndLogin(tabNum) {
	OpeTabs(tabNum);
	iimPlay("FundSystem/01.LoginFundSystem.iim");
}

function WaitPop() {
	do {}
	while (window.location.href.indexOf(".pdf") == -1)
}

//開啟新頁籤
function OpeTabs(tabNum) {
	var macro;
	macro = "CODE:";
	macro += "TAB OPEN" + "\n";
	macro += "TAB T=" + tabNum + "\n";
	iimPlay(macro);
}

//從csv讀取取款資料
function ReadTaDataFromCsv(sourceFile, valuedate) {
	var load,
	content,
	spl,
	index_count;
	var bankname,
	acc,
	accname,
	amt,
	fundNo,
	feeType,
	note;

	var macro;
	macro = "CODE:";
	macro += "FRAME NAME=\"ifrConfirmEdit\"" + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:met29022 ATTR=ID:withdrawDate CONTENT=" + valuedate + "\n";
	iimPlay(macro);

	//設定筆數
	load = "CODE:";
	load += "SET !DATASOURCE " + sourceFile + "\n";
	load += "SET !DATASOURCE_COLUMNS 1" + "\n";
	load += "SET !DATASOURCE_LINE {{i}}" + "\n";
	load += "SET !extract {{!col1}}" + "\n";
	var lastRow = GetLastRowCount(load);
	for (i = 0; i < lastRow - 3; i++) {
		var macro;
		macro = "CODE:";
		macro += "FRAME NAME=\"ifrConfirmEdit\"" + "\n";
		macro += "TAG POS=1 TYPE=BUTTON FORM=ID:met29022 ATTR=ID:btnInsRow" + "\n";
		iimPlay(macro);
	}

	//讀取存款資料
	load = GetLoadCode(sourceFile);

	index_count = 0
		for (i = 2; i < lastRow; i++) {
			iimSet("i", i);
			// Load data
			iimPlay(load);
			content = iimGetLastExtract();
			if (content != "") {
				spl = content.split("|");
				//契約編號
				fundNo = spl[0];
				//取款帳號
				acc = spl[1];
				//金額
				amt = spl[2];
				//備註
				note = spl[3];
				SetTakeDataIntoForm(index_count, fundNo, acc, amt, note);
				index_count++;
			}

		}
		//列印報表
		if (index_count != 0) {
			StartPrintTake();
		}

}

//從csv讀取匯款資料
function ReadExDataFromCsv(sourceFile, valuedate, persionid) {
	var load,
	content,
	spl,
	index_count;
	var bankname,
	acc,
	accname,
	amt,
	fundNo,
	feeType,
	note;

	var macro;
	macro = "CODE:";
	macro += "FRAME NAME=\"ifrConfirmEdit\"" + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:met29022Form ATTR=ID:rmtDate CONTENT=" + valuedate + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:met29022Form ATTR=ID:rmtTel CONTENT=23495242" + "\n";
	iimPlay(macro);

	//設定筆數
	load = "CODE:";
	load += "SET !DATASOURCE " + sourceFile + "\n";
	load += "SET !DATASOURCE_COLUMNS 1" + "\n";
	load += "SET !DATASOURCE_LINE {{i}}" + "\n";
	load += "SET !extract {{!col1}}" + "\n";
	var lastRow = GetLastRowCount(load);
	for (i = 0; i < lastRow - 3; i++) {
		var macro;
		macro = "CODE:";
		macro += "FRAME NAME=\"ifrConfirmEdit\"" + "\n";
		macro += "TAG POS=1 TYPE=BUTTON FORM=ID:met29022Form ATTR=ID:btnInsRow" + "\n";
		iimPlay(macro);
	}

	//讀取匯款資料
	load = GetLoadCode(sourceFile);
	index_count = 0
		for (i = 2; i < lastRow; i++) {
			iimSet("i", i);
			// Load data
			iimPlay(load);
			content = iimGetLastExtract();
			if (content != "") {
				spl = content.split("|");
				//契約編號
				fundNo = spl[0];
				//匯款銀行
				bankname = spl[1];
				//匯款帳號
				acc = spl[2];
				//戶名
				accname = spl[3];
				//匯費扣款方式(01內扣/02外加)
				feeType = spl[4];
				//金額
				amt = spl[5];
				//備註
				note = spl[6];
				SetExchangeDataIntoForm(index_count, fundNo, bankname, acc, accname, amt, persionid, feeType, note);
				index_count++;
			}

		}
		//列印報表
		if (index_count != 0) {
			StartPrint();
		}

}

//從csv讀取存款資料
function ReadSaDataFromCsv(sourceFile, valuedate, isSendType) {
	var load,
	content,
	spl,
	index_count;
	var bankname,
	acc,
	accname,
	amt,
	fundNo,
	feeType,
	note;

	var macro;
	macro = "CODE:";
	macro += "FRAME NAME=\"ifrConfirmEdit\"" + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:met29023 ATTR=ID:depositDate CONTENT=" + valuedate + "\n";
	iimPlay(macro);

	if (isSendType == "Y") {
		macro = "CODE:";
		macro += "FRAME NAME=\"ifrConfirmEdit\"" + "\n";
		macro += "TAG POS=1 TYPE=INPUT:RADIO FORM=ID:met29023 ATTR=ID:formType2" + "\n";
		iimPlay(macro);
	}

	//設定筆數
	load = "CODE:";
	load += "SET !DATASOURCE " + sourceFile + "\n";
	load += "SET !DATASOURCE_COLUMNS 1" + "\n";
	load += "SET !DATASOURCE_LINE {{i}}" + "\n";
	load += "SET !extract {{!col1}}" + "\n";
	var lastRow = GetLastRowCount(load);
	for (i = 0; i < lastRow - 3; i++) {
		var macro;
		macro = "CODE:";
		macro += "FRAME NAME=\"ifrConfirmEdit\"" + "\n";
		macro += "TAG POS=1 TYPE=BUTTON FORM=ID:met29023 ATTR=ID:btnInsRow" + "\n";
		iimPlay(macro);
	}

	//讀取存款資料
	load = GetLoadCode(sourceFile);

	index_count = 0
		for (i = 2; i < lastRow; i++) {
			iimSet("i", i);
			// Load data
			iimPlay(load);
			content = iimGetLastExtract();
			if (content != "") {
				spl = content.split("|");
				//契約編號
				fundNo = spl[0];
				//存款帳號
				acc = spl[1];
				//帳戶名稱
				bankname = spl[2];
				//金額
				amt = spl[3];
				//備註
				note = spl[4];
				SetSaveDataIntoForm(index_count, fundNo, acc, bankname, amt, note);
				index_count++;
			}

		}
		//列印報表
		if (index_count != 0) {
			StartPrintSave();
		}

}

//取得讀取的CSV的執行code
function GetLoadCode(sourceFile) {
	var load;
	load = "CODE:";
	load += "SET !EXTRACT null" + "\n";
	load += "SET !DATASOURCE " + sourceFile + "\n";
	load += "SET !DATASOURCE_COLUMNS 7" + "\n";
	load += "SET !DATASOURCE_LINE {{i}}" + "\n";
	load += "SET !EXTRACT {{!col1}}|{{!col2}}|{{!col3}}|{{!col4}}|{{!col5}}|{{!col6}}|{{!col7}}" + "\n";
	return load;
}

//取得CSV最後一行
function GetLastRowCount(code) {
	const EOF = -951;
	var moreRows = true;
	var row = 1;
	var ret;
	while (moreRows) {
		iimSet("i", row);
		ret = iimPlay(code);
		if (ret == EOF) {
			moreRows = false;
		} else {
			getData = iimGetLastExtract();
			row++;
		}
	}
	return row;
}

//設定匯款功能初始設定
function SetAMMET29020Init(typeItem) {
	var macro;
	macro = "CODE:";
	macro += "FRAME NAME=\"mainPanel\"" + "\n";
	macro += "TAG POS=1 TYPE=SELECT FORM=ID:met29020 ATTR=ID:transferCategory CONTENT=%" + typeItem + "\n";
	macro += "TAG POS=1 TYPE=BUTTON FORM=ID:met29020 ATTR=ID:btnSmt" + "\n";
	iimPlay(macro);
}

//將匯款資料填入表單
function SetExchangeDataIntoForm(index_count, fundNo, bankname, acc, accname, amt, persionid, feeType, note) {
	var macro;
	macro = "CODE:";
	macro += "FRAME NAME=\"ifrConfirmEdit\"" + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:met29022Form ATTR=ID:contrNo_" + index_count + " CONTENT=" + fundNo + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:met29022Form ATTR=ID:bnfcryNam_" + index_count + " CONTENT=" + bankname + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:met29022Form ATTR=ID:payeeAcno_" + index_count + " CONTENT=" + acc + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:met29022Form ATTR=ID:payeeAcnoNam_" + index_count + " CONTENT=" + accname + "\n";
	macro += "TAG POS=1 TYPE=SELECT FORM=ID:met29022Form ATTR=ID:rmtFeeDeduTyp_" + index_count + " CONTENT=%" + feeType + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:met29022Form ATTR=ID:rmtAmt_" + index_count + " CONTENT=" + amt + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:met29022Form ATTR=ID:agentId_" + index_count + " CONTENT=" + persionid + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:met29022Form ATTR=ID:agentTel_" + index_count + " CONTENT=23495242" + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:met29022Form ATTR=ID:description_" + index_count + " CONTENT=" + note + "\n";
	iimPlay(macro);
}

//將取款資料填入表單
function SetTakeDataIntoForm(index_count, fundNo, acc, amt, note) {
	var macro;
	macro = "CODE:";
	macro += "FRAME NAME=\"ifrConfirmEdit\"" + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:met29022 ATTR=ID:contrNo_" + index_count + " CONTENT=" + fundNo + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:met29022 ATTR=ID:bankAcno_" + index_count + " CONTENT=" + acc + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:met29022 ATTR=ID:withdrawAmount_" + index_count + " CONTENT=" + amt + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:met29022 ATTR=ID:description_" + index_count + " CONTENT=" + note + "\n";
	iimPlay(macro);
}

/* AMMET29020  公用轉檔－取款／匯款／存款處理(人工)
 * 贖回資料(存條)
 */
function SetSaveDataIntoForm(index_count, fundNo, acc, bankname, amt, note) {
	var macro;
	macro = "CODE:";
	macro += "FRAME NAME=\"ifrConfirmEdit\"" + "\n";
	if (fundNo != "") {
		macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:met29023 ATTR=ID:contrNo_" + index_count + " CONTENT=" + fundNo + "\n";
	}
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:met29023 ATTR=ID:bankAcno_" + index_count + " CONTENT=" + acc + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:met29023 ATTR=ID:acnoNam_" + index_count + " CONTENT=" + bankname + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:met29023 ATTR=ID:depositAmount_" + index_count + " CONTENT=" + amt + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:met29023 ATTR=ID:description_" + index_count + " CONTENT=" + note + "\n";
	iimPlay(macro);
}

//開始處理
function StartPrint() {
	var macro;
	macro = "CODE:";
	macro += "FRAME NAME=\"ifrConfirmEdit\"" + "\n";
	macro += "TAG POS=1 TYPE=BUTTON FORM=ID:met29022Form ATTR=ID:btnPrs" + "\n";
	iimPlay(macro);
}

//開始處理
function StartPrintTake() {
	var macro;
	macro = "CODE:";
	macro += "FRAME NAME=\"ifrConfirmEdit\"" + "\n";
	macro += "TAG POS=1 TYPE=BUTTON FORM=ID:met29022 ATTR=ID:btnPrs" + "\n";
	iimPlay(macro);
}

//開始處理
function StartPrintSave() {
	var macro;
	macro = "CODE:";
	macro += "FRAME NAME=\"ifrConfirmEdit\"" + "\n";
	macro += "TAG POS=1 TYPE=BUTTON FORM=ID:met29023 ATTR=ID:btnPrs" + "\n";
	iimPlay(macro);
}

//設定基金功能代號
function SetFuncNo(prgid) {
	var macro;
	macro = "CODE:";
	macro += "TAG POS=1 TYPE=INPUT:TEXT ATTR=ID:findProgId CONTENT=" + prgid + "\n";
	macro += "TAG POS=1 TYPE=BUTTON ATTR=ID:findProgBtn" + "\n";
	iimPlay(macro)
}

//取當日
function GetToday() {
	//取當日
	var enddate = new Date();
	return SetDateformat(enddate)
}

//設定日期格式(yyyy/mm/dd)
function SetDateformat(Date) {
	var Y = Date.getFullYear();
	var M = Date.getMonth() + 1;
	M = M < 10 ? '0' + M : M;
	var D = Date.getDate();
	D = D < 10 ? '0' + D : D;
	return Y + '/' + M + '/' + D
}
