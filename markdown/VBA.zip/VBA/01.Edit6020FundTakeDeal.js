﻿/*
'*************************************************************************************
'專案名稱: 全權委託
'功能描述: 設定基金贖回交易登打
'版權所有: 台灣銀行
'程式撰寫: Dunk
'撰寫日期：2021/3/25
'
'改版日期:
'改版備註:
'*************************************************************************************
 */

Main()

//程式進入點
function Main() {
	//登入系統
	iimPlay("DisSystem/01.LoginDisSystem.iim");
	ReadDataFromCsv("D:\\贖回設定.csv");

}

//從csv讀取基金贖回匯款資料
function ReadDataFromCsv(sourceFile) {
	var load,
	content,
	spl,
	index_count;
	var sellFundId,
	sellUnit,
	valuedate,
	printDate;

	//契約編號
	fundNo = window.prompt("請輸入契約編號(預設B6020)：");
	if (fundNo == "") {
		fundNo = "B6020";
	}
	//作帳日期設定(預設T-1 Day)
	printDate = GetPreBsnDate();

	var valuedate = window.prompt("請輸入贖回金額付款日期(yyyy/mm/dd)：");
	if (valuedate == "") {
		window.prompt("未輸入日期!已取消");
		return;
	}

	//設定筆數
	load = "CODE:";
	load += "SET !DATASOURCE " + sourceFile + "\n";
	load += "SET !DATASOURCE_COLUMNS 1" + "\n";
	load += "SET !DATASOURCE_LINE {{i}}" + "\n";
	load += "SET !extract {{!col1}}" + "\n";
	var lastRow = GetLastRowCount(load);

	//讀取申購資料
	load = GetLoadCode(sourceFile);
	index_count = 0
		for (i = 2; i < lastRow; i++) {
			iimSet("i", i);
			// Load data
			iimPlay(load);
			content = iimGetLastExtract();
			if (content != "") {
				spl = content.split("|");
				//申購基金編號
				sellFundId = spl[0];
				//單位數
				sellUnit = spl[2];
				SetFuncNo("AMDAL06000");
				SetPlaceDataIntoForm(fundNo, valuedate, sellFundId, sellUnit);
				index_count++;
			}

		}

		// 列印報表
		if (index_count != 0) {
			PrintDealReport(fundNo, printDate);
		}

}

//取得讀取的CSV的執行code
function GetLoadCode(sourceFile) {
	var load;
	load = "CODE:";
	load += "SET !EXTRACT null" + "\n";
	load += "SET !DATASOURCE " + sourceFile + "\n";
	load += "SET !DATASOURCE_COLUMNS 7" + "\n";
	load += "SET !DATASOURCE_LINE {{i}}" + "\n";
	load += "SET !EXTRACT {{!col1}}|{{!col2}}|{{!col3}}|{{!col4}}|{{!col5}}|{{!col6}}|{{!col7}}" + "\n";
	return load;
}

//取得CSV最後一行
function GetLastRowCount(code) {
	const EOF = -951;
	var moreRows = true;
	var row = 1;
	var ret;
	while (moreRows) {
		iimSet("i", row);
		ret = iimPlay(code);
		if (ret == EOF) {
			moreRows = false;
		} else {
			getData = iimGetLastExtract();
			row++;
		}
	}
	return row;
}

//將贖回基金資料填入表單
function SetPlaceDataIntoForm(fundNo, valuedate, sellFundId, sellUnit) {
	var macro;
	macro = "CODE:";
	macro += "FRAME NAME=\"mainPanel\"" + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:frmDal06000 ATTR=ID:contrNo CONTENT=" + fundNo + "\n";
	macro += "TAG POS=1 TYPE=BUTTON FORM=ID:frmDal06000 ATTR=ID:btnSmt" + "\n";
	macro += "FRAME NAME=\"ifrConfirmEdit\"" + "\n";
	macro += "TAG POS=1 TYPE=INPUT:CHECKBOX FORM=ID:frmDal06000 ATTR=ID:checkBox_0 CONTENT=YES" + "\n";
	macro += "TAG POS=1 TYPE=SELECT FORM=ID:frmDal06000 ATTR=ID:txType_0 CONTENT=%2" + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:frmDal06000 ATTR=ID:prdCde_0 CONTENT=" + sellFundId + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:frmDal06000 ATTR=ID:sellDealQty_0 CONTENT=" + sellUnit + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:frmDal06000 ATTR=ID:vluDate_0 CONTENT=" + valuedate + "\n";
	macro += "TAG POS=1 TYPE=BUTTON FORM=ID:frmDal06000 ATTR=ID:btnSmt" + "\n";
	iimPlay(macro);
}

//列印投資商品日報表
function PrintDealReport(fundNo, valuedate) {
	SetFuncNo("AMRPT01100");
	var macro;
	macro = "CODE:";
	macro += "FRAME NAME=\"mainPanel\"" + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:rpt01100 ATTR=ID:dealDateStr CONTENT=" + valuedate + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:rpt01100 ATTR=ID:dealDateEnd CONTENT=" + valuedate + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:rpt01100 ATTR=ID:contrNoStr CONTENT=" + fundNo + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:rpt01100 ATTR=ID:contrNoEnd CONTENT=" + fundNo + "\n";
	macro += "TAG POS=1 TYPE=INPUT:CHECKBOX FORM=ID:rpt01100 ATTR=NAME:criteria.type06 CONTENT=YES" + "\n";
	macro += "TAG POS=1 TYPE=BUTTON FORM=ID:rpt01100 ATTR=ID:btnRpt" + "\n";
	iimPlay(macro);
	StartPrint();
}

//設定基金功能代號
function SetFuncNo(prgid) {
	var macro;
	macro = "CODE:";
	macro += "TAG POS=1 TYPE=INPUT:TEXT ATTR=ID:findProgId CONTENT=" + prgid + "\n";
	macro += "TAG POS=1 TYPE=BUTTON ATTR=ID:findProgBtn" + "\n";
	iimPlay(macro)
}

//取得前一營業日
function GetPreBsnDate() {
	var file = Components.classes["@mozilla.org/file/local;1"]
		.createInstance(Components.interfaces.nsILocalFile);
	file.initWithPath("D:\\SciTE4AutoIt3_Portable\\code\\DateDeal\\GetPreBsnDate.exe");
	file.launch();
	sleep(8000);
	return ReadFundNoFromClipBorad();
}

//從剪貼簿讀取基金編號資料
function ReadFundNoFromClipBorad() {
	var fundNo;
	var macro;
	macro = "CODE:";
	macro += "SET !extract {{!CLIPBOARD}}" + "\n";
	iimPlay(macro)
	fundNo = iimGetLastExtract(1);
	return fundNo;
}

//開始列印
function StartPrint() {
	do {}
	while (window.location.href.indexOf(".pdf") == -1)
	sleep(1000);
	CallPrintSetup();
	sleep(5000);
	ChangeTabToOne();
}

//關閉頁籤
function ChangeTabToOne() {
	var macro;
	macro = "CODE:";
	macro += "TAB CLOSE" + "\n";
	iimPlay(macro)
}

//呼叫列印工具
function CallPrintSetup() {
	var file = Components.classes["@mozilla.org/file/local;1"]
		.createInstance(Components.interfaces.nsILocalFile);
	file.initWithPath("D:\\SciTE4AutoIt3_Portable\\code\\firefox\\PrintFileSet.exe");
	file.launch();
}

//暫停執行
function sleep(milliseconds) {
	var start = new Date().getTime();
	for (var i = 0; i < 1e7; i++) {
		if ((new Date().getTime() - start) > milliseconds) {
			break;
		}
	}
}
