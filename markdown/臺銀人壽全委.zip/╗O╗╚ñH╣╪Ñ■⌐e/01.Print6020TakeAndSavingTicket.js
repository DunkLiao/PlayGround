﻿/*
'*************************************************************************************
'專案名稱: 全權委託
'功能描述: 設定台銀人壽全委買回存取條取條
'
'版權所有: 台灣銀行
'程式撰寫: Dunk
'撰寫日期：2021/1/11
'
'改版日期:
'改版備註:
'
'
'*************************************************************************************
 */

//程式進入點
Main();

function Main() {
	iimPlay("DisSystem/01.LoginDisSystem.iim");
	GetAllTakeSaveData();
}

//取得基金申購取款單
function GetAllTakeSaveData() {
	//契約編號
	fundNo = window.prompt("請輸入契約編號(預設B6020)：");
	if (fundNo == "") {
		fundNo = "B6020";
	}
	//申購款交割日
	var valuedate = window.prompt("請輸入取存款日期(yyyy/mm/dd)：");
	if (valuedate == "") {
		valuedate = GetToday();
	}
	//取款金額
	var amt = window.prompt("請輸入金額：");

	/*設定取款資料*/
	GetTakeData(fundNo, amt, valuedate);
	OpenTabAndLogin(2);	
	GetSaveData(amt, valuedate);
}

//開啟頁籤並登入
function OpenTabAndLogin(tabNum) {
	OpeTabs(tabNum);
	iimPlay("DisSystem/01.LoginDisSystem.iim");
}

//開啟新頁籤
function OpeTabs(tabNum) {
	var macro;
	macro = "CODE:";
	macro += "TAB OPEN" + "\n";
	macro += "TAB T=" + tabNum + "\n";
	iimPlay(macro);
}

/* AMMET29020  公用轉檔－取款／匯款／存款處理(人工)
 * 贖回資料(取條)
 */
function GetTakeData(disNoStart, amt, queryDate) {
	SetFuncNo("AMMET29020");
	var macro;
	macro = "CODE:";
	macro += "FRAME NAME=\"mainPanel\"" + "\n";
	macro += "TAG POS=1 TYPE=SELECT FORM=ID:met29020 ATTR=ID:transferCategory CONTENT=%01" + "\n";
	macro += "TAG POS=1 TYPE=BUTTON FORM=ID:met29020 ATTR=ID:btnSmt" + "\n";
	macro += "FRAME NAME=\"ifrConfirmEdit\"" + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:met29022 ATTR=ID:withdrawDate CONTENT=" + queryDate + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:met29022 ATTR=ID:contrNo_0 CONTENT=" + disNoStart + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:met29022 ATTR=ID:withdrawAmount_0 CONTENT=" + amt + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:met29022 ATTR=ID:description_0 CONTENT=支付贖回款" + "\n";
	macro += "TAG POS=1 TYPE=BUTTON FORM=ID:met29022 ATTR=ID:btnPrs" + "\n";
	iimPlay(macro);
}

/* AMMET29020  公用轉檔－取款／匯款／存款處理(人工)
 * 贖回資料(取條)
 */
function GetSaveData(amt, queryDate) {	
	SetFuncNo("AMMET29020");
	var macro;
	macro = "CODE:";
	macro += "FRAME NAME=\"mainPanel\"" + "\n";
	macro += "TAG POS=1 TYPE=SELECT FORM=ID:met29020 ATTR=ID:transferCategory CONTENT=%03" + "\n";
	macro += "TAG POS=1 TYPE=BUTTON FORM=ID:met29020 ATTR=ID:btnSmt" + "\n";
	macro += "FRAME NAME=\"ifrConfirmEdit\"" + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:met29023 ATTR=ID:depositDate CONTENT=" + queryDate + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:met29023 ATTR=ID:acnoNam_0 CONTENT=臺銀人壽保險股份有限公司" + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:met29023 ATTR=ID:bankAcno_0 CONTENT=086001022107" + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:met29023 ATTR=ID:description_0 CONTENT=支付贖回款" + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:met29023 ATTR=ID:depositAmount_0 CONTENT=" + amt + "\n";
	macro += "TAG POS=1 TYPE=BUTTON FORM=ID:met29023 ATTR=ID:btnPrs" + "\n";
	iimPlay(macro);
}

//設定基金功能代號
function SetFuncNo(prgid) {
	var macro;
	macro = "CODE:";
	macro += "TAG POS=1 TYPE=INPUT:TEXT ATTR=ID:findProgId CONTENT=" + prgid + "\n";
	macro += "TAG POS=1 TYPE=BUTTON ATTR=ID:findProgBtn" + "\n";
	iimPlay(macro);
}

//取當日
function GetToday() {
	//取當日
	var enddate = new Date();
	return SetDateformat(enddate)
}

//設定日期格式(yyyy/mm/dd)
function SetDateformat(Date) {
	var Y = Date.getFullYear();
	var M = Date.getMonth() + 1;
	M = M < 10 ? '0' + M : M;
	var D = Date.getDate();
	D = D < 10 ? '0' + D : D;
	return Y + '/' + M + '/' + D
}
