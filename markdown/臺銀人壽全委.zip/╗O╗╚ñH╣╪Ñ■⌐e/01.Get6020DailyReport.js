﻿/*
'*************************************************************************************
'專案名稱: 全權委託
'功能描述: 下載台銀人壽全委結帳報表
'
'版權所有: 台灣銀行
'程式撰寫: Dunk
'撰寫日期：2021/1/18
'
'改版日期:
'改版備註:
'
'
'*************************************************************************************
 */

//程式進入點
Main();

function Main() {
	iimPlay("DisSystem/01.LoginDisSystem.iim");
	//取得會計科目彙總表
	Get189902Rpt();
}

//取得會計科目彙總表
function Get189902Rpt() {
	var valueDate = window.prompt("台銀人壽全委結帳報表\n要查詢的日期(yyyy/mm/dd)(預設為前一營業日)：");
	if (valueDate == "") {
		valueDate = GetPreBsnDate();
	}
	var fundNo;
	fundNo = "B6020";
	//下載資產負債表
	DoAMRPT23110(valueDate, fundNo);
	//下載委任投資資產現況報告書
	DoAMRPT08004(valueDate, fundNo);
}

//取得存檔資料夾
function GetFolder() {
	return "D:\\"
}

//取得存檔檔案名稱(資產負債表)
function GetSaveFileNameBs() {
	return "BS保銀.xls"
}
//取得存檔檔案名稱(委任投資資產現況報告書)()
function GetSaveFileNameIs() {
	return "庫存保銀.xls"
}

//取當日
function GetToday() {
	//取當日
	var enddate = new Date();
	return SetDateformat(enddate)
}

//設定日期格式(yyyy/mm/dd)
function SetDateformat(Date) {
	var Y = Date.getFullYear();
	var M = Date.getMonth() + 1;
	M = M < 10 ? '0' + M : M;
	var D = Date.getDate();
	D = D < 10 ? '0' + D : D;
	return Y + '/' + M + '/' + D
}

//設定基金功能代號
function SetFuncNo(prgid) {
	var macro;
	macro = "CODE:";
	macro += "TAG POS=1 TYPE=INPUT:TEXT ATTR=ID:findProgId CONTENT=" + prgid + "\n";
	macro += "TAG POS=1 TYPE=BUTTON ATTR=ID:findProgBtn" + "\n";
	iimPlay(macro)
}

//下載資產負債表
function DoAMRPT23110(queryDate, fundNo) {
	SetFuncNo("AMRPT23110");
	var macro;
	macro = "CODE:";
	macro += "FRAME NAME=\"mainPanel\"" + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:frmRpt23110 ATTR=ID:contrNoStr CONTENT=" + fundNo + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:frmRpt23110 ATTR=ID:contrNoEnd CONTENT=" + fundNo + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:frmRpt23110 ATTR=ID:dataDate CONTENT=" + queryDate + "\n";
	macro += "TAG POS=1 TYPE=SELECT FORM=ID:frmRpt23110 ATTR=ID:rptType CONTENT=%xls" + "\n";
	macro += "ONDOWNLOAD FOLDER=" + GetFolder() + " FILE=" + GetSaveFileNameBs() + " WAIT=YES" + "\n";
	macro += "TAG POS=1 TYPE=BUTTON FORM=ID:frmRpt23110 ATTR=ID:btnRpt" + "\n";
	iimPlay(macro);
}

//下載委任投資資產現況報告書
function DoAMRPT08004(queryDate, fundNo) {
	SetFuncNo("AMRPT08004");
	var macro;
	macro = "CODE:";
	macro += "FRAME NAME=\"mainPanel\"" + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:frmRpt08004 ATTR=ID:contrNoStr CONTENT=" + fundNo + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:frmRpt08004 ATTR=ID:contrNoEnd CONTENT=" + fundNo + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:frmRpt08004 ATTR=ID:invtryDate CONTENT=" + queryDate + "\n";
	macro += "TAG POS=1 TYPE=SELECT FORM=ID:frmRpt08004 ATTR=ID:rptName CONTENT=%1" + "\n";
	macro += "TAG POS=1 TYPE=SELECT FORM=ID:frmRpt08004 ATTR=ID:rptType CONTENT=%xls" + "\n";
	macro += "ONDOWNLOAD FOLDER=" + GetFolder() + " FILE=" + GetSaveFileNameIs() + " WAIT=YES" + "\n";
	macro += "TAG POS=1 TYPE=BUTTON FORM=ID:frmRpt08004 ATTR=ID:btnRpt" + "\n";
	iimPlay(macro);
}

//取得前一營業日
function GetPreBsnDate() {
	var file = Components.classes["@mozilla.org/file/local;1"]
		.createInstance(Components.interfaces.nsILocalFile);
	file.initWithPath("D:\\SciTE4AutoIt3_Portable\\code\\DateDeal\\GetPreBsnDate.exe");
	file.launch();
	sleep(8000);
	return ReadFundNoFromClipBorad();
}

//從剪貼簿讀取基金編號資料
function ReadFundNoFromClipBorad() {
	var fundNo;
	var macro;
	macro = "CODE:";
	macro += "SET !extract {{!CLIPBOARD}}" + "\n";
	iimPlay(macro)
	fundNo = iimGetLastExtract(1);
	return fundNo;
}

//暫停執行
function sleep(milliseconds) {
	var start = new Date().getTime();
	for (var i = 0; i < 1e7; i++) {
		if ((new Date().getTime() - start) > milliseconds) {
			break;
		}
	}
}
