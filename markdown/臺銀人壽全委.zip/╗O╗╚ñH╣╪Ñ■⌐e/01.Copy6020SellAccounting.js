﻿/*
'*************************************************************************************
'專案名稱: 全權委託
'功能描述: 複製臺銀人壽全委保單買回會計分錄
'版權所有: 台灣銀行
'程式撰寫: Dunk
'撰寫日期：2021/1/20
'
'改版日期:
'改版備註:
'*************************************************************************************
 */

Main()

//程式進入點
function Main() {
	//登入系統
	iimPlay("DisSystem/01.LoginDisSystem.iim");
	CopyAccounting();

}

//複製會計分錄
function CopyAccounting() {

	SetFuncNo("AMACT01004");
	var macro;
	macro = "CODE:";
	macro += "FRAME NAME=\"mainPanel\"" + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:act01004 ATTR=ID:contrNo CONTENT=B6020" + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:act01004 ATTR=ID:bookDate CONTENT=2021/01/18" + "\n";
	macro += "TAG POS=1 TYPE=SELECT FORM=ID:act01004 ATTR=ID:bookAttr CONTENT=%7" + "\n";
	macro += "TAG POS=1 TYPE=BUTTON FORM=ID:act01004 ATTR=ID:listBtnBrw" + "\n";
	macro +=  "TAG POS=1 TYPE=INPUT:IMAGE FORM=ID:act01004 ATTR=SRC:https://trsacs.bot.com.tw/am/image_icons/copy.png" + "\n"; 
	iimPlay(macro);

}
//設定基金功能代號
function SetFuncNo(prgid) {
	var macro;
	macro = "CODE:";
	macro += "TAG POS=1 TYPE=INPUT:TEXT ATTR=ID:findProgId CONTENT=" + prgid + "\n";
	macro += "TAG POS=1 TYPE=BUTTON ATTR=ID:findProgBtn" + "\n";
	iimPlay(macro);
}
