﻿/*
'*************************************************************************************
'專案名稱: 全權委託
'功能描述: 設定基金申購匯款單
'https://stackoverflow.com/questions/29586878/put-csv-data-to-array-imacros-js
'版權所有: 台灣銀行
'程式撰寫: Dunk
'撰寫日期：2021/1/12
'
'改版日期:
'改版備註: 2021/1/13 修改取款條
'*************************************************************************************
 */

Main()

//程式進入點
function Main() {
	//登入系統

	iimPlay("DisSystem/01.LoginDisSystem.iim");
	SetFuncNo("AMMET29020");
	SetAMMET29020Init();
	ReadDataFromCsv("D:\\申購設定.csv");

}

//從csv讀取基金申購匯款資料
function ReadDataFromCsv(sourceFile) {
	var load,
	content,
	spl,
	index_count;
	var bankname,
	acc,
	accname,
	amt,
	fundNo,
	valuedate,
	persionid;

	//契約編號
	fundNo = window.prompt("請輸入契約編號(預設B6020)：");
	if (fundNo == "") {
		fundNo = "B6020";
	}

	//匯款日期設定
	var valuedate = window.prompt("請輸入匯款日期(yyyy/mm/dd)：");
	if (valuedate == "") {
		valuedate = GetToday();
	}
	var macro;
	macro = "CODE:";
	macro += "FRAME NAME=\"ifrConfirmEdit\"" + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:met29022Form ATTR=ID:rmtDate CONTENT=" + valuedate + "\n";
	iimPlay(macro);

	//身份號
	persionid = window.prompt("請輸入身份證號：");

	//設定筆數
	load = "CODE:";
	load += "SET !DATASOURCE " + sourceFile + "\n";
	load += "SET !DATASOURCE_COLUMNS 1" + "\n";
	load += "SET !DATASOURCE_LINE {{i}}" + "\n";
	load += "SET !extract {{!col1}}" + "\n";
	var lastRow = GetLastRowCount(load);
	for (i = 0; i < lastRow - 3; i++) {
		var macro;
		macro = "CODE:";
		macro += "FRAME NAME=\"ifrConfirmEdit\"" + "\n";
		macro += "TAG POS=1 TYPE=BUTTON FORM=ID:met29022Form ATTR=ID:btnInsRow" + "\n";
		iimPlay(macro);
	}

	//讀取匯款資料
	load = GetLoadCode(sourceFile);

	index_count = 0
		for (i = 2; i < lastRow; i++) {
			iimSet("i", i);
			// Load data
			iimPlay(load);
			content = iimGetLastExtract();
			if (content != "") {
				spl = content.split("|");
				//匯款銀行
				bankname = spl[1];
				//匯款帳號
				acc = spl[2];
				//戶名
				accname = spl[3];
				//金額
				amt = spl[4];
				SetTakeDataIntoForm(index_count, fundNo, bankname, acc, accname, amt, persionid);
				index_count++;
			}

		}
		//列印報表
		if (index_count != 0) {
			StartPrint();
		}

}

//取得讀取的CSV的執行code
function GetLoadCode(sourceFile) {
	var load;
	load = "CODE:";
	load += "SET !EXTRACT null" + "\n";
	load += "SET !DATASOURCE " + sourceFile + "\n";
	load += "SET !DATASOURCE_COLUMNS 7" + "\n";
	load += "SET !DATASOURCE_LINE {{i}}" + "\n";
	load += "SET !EXTRACT {{!col1}}|{{!col2}}|{{!col3}}|{{!col4}}|{{!col5}}|{{!col6}}|{{!col7}}" + "\n";
	return load;
}

//取得CSV最後一行
function GetLastRowCount(code) {
	const EOF = -951;
	var moreRows = true;
	var row = 1;
	var ret;
	while (moreRows) {
		iimSet("i", row);
		ret = iimPlay(code);
		if (ret == EOF) {
			moreRows = false;
		} else {
			getData = iimGetLastExtract();
			row++;
		}
	}
	return row;
}

//設定匯款功能初始設定
function SetAMMET29020Init() {
	var macro;
	macro = "CODE:";
	macro += "FRAME NAME=\"mainPanel\"" + "\n";
	macro += "TAG POS=1 TYPE=SELECT FORM=ID:met29020 ATTR=ID:transferCategory CONTENT=%02" + "\n";
	macro += "TAG POS=1 TYPE=BUTTON FORM=ID:met29020 ATTR=ID:btnSmt" + "\n";
	macro += "FRAME NAME=\"ifrConfirmEdit\"" + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:met29022Form ATTR=ID:rmtTel CONTENT=23495242" + "\n";
	iimPlay(macro);
}

//將匯款資料填入表單
function SetTakeDataIntoForm(index_count, fundNo, bankname, acc, accname, amt, persionid) {
	var macro;
	macro = "CODE:";
	macro += "FRAME NAME=\"ifrConfirmEdit\"" + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:met29022Form ATTR=ID:contrNo_" + index_count + " CONTENT=" + fundNo + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:met29022Form ATTR=ID:bnfcryNam_" + index_count + " CONTENT=" + bankname + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:met29022Form ATTR=ID:payeeAcno_" + index_count + " CONTENT=" + acc + "\n";
	//匯費預設外加
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:met29022Form ATTR=ID:payeeAcnoNam_" + index_count + " CONTENT=" + accname + "\n";
	macro += "TAG POS=1 TYPE=SELECT FORM=ID:met29022Form ATTR=ID:rmtFeeDeduTyp_" + index_count + " CONTENT=%02" + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:met29022Form ATTR=ID:rmtAmt_" + index_count + " CONTENT=" + amt + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:met29022Form ATTR=ID:agentId_" + index_count + " CONTENT=" + persionid + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:met29022Form ATTR=ID:agentTel_" + index_count + " CONTENT=23495242" + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:met29022Form ATTR=ID:description_" + index_count + " CONTENT=基金申購" + "\n";
	iimPlay(macro);
}

//開始處理
function StartPrint() {
	var macro;
	macro = "CODE:";
	macro += "FRAME NAME=\"ifrConfirmEdit\"" + "\n";
	macro += "TAG POS=1 TYPE=BUTTON FORM=ID:met29022Form ATTR=ID:btnPrs" + "\n";
	iimPlay(macro)
}

//設定基金功能代號
function SetFuncNo(prgid) {
	var macro;
	macro = "CODE:";
	macro += "TAG POS=1 TYPE=INPUT:TEXT ATTR=ID:findProgId CONTENT=" + prgid + "\n";
	macro += "TAG POS=1 TYPE=BUTTON ATTR=ID:findProgBtn" + "\n";
	iimPlay(macro)
}

//取當日
function GetToday() {
	//取當日
	var enddate = new Date();
	return SetDateformat(enddate)
}

//設定日期格式(yyyy/mm/dd)
function SetDateformat(Date) {
	var Y = Date.getFullYear();
	var M = Date.getMonth() + 1;
	M = M < 10 ? '0' + M : M;
	var D = Date.getDate();
	D = D < 10 ? '0' + D : D;
	return Y + '/' + M + '/' + D
}
