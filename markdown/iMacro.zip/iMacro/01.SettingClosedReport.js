﻿/*
'*************************************************************************************
'專案名稱: 全權委託
'功能描述: 設定全委拋帳報表
'
'版權所有: 台灣銀行
'程式撰寫: Dunk
'撰寫日期：2018/8/14
'
'改版日期:
'改版備註: 2018/8/16 增加契約關卡關閉處理-整批
'          2018/9/19 增加庫存及會計比對暨異常表列印
'          2018/10/2 調整900關卡關閉設定
'          2018/11/2 增加6019的900關卡關閉設定
'          2021/1/25 增加6020的900關卡關閉設定
'*************************************************************************************
 */

//程式進入點
Main();

function Main() {

	iimPlay("DisSystem/01.LoginDisSystem.iim");

	//庫存及會計比對暨異常表列印(A>01>8)
	SetFuncNo("AMACT01031");
	SettingAMACT01031();

	//契約關卡關閉處理-整批(A>05>2)
	OpenTabAndLogin(2);
	SetFuncNo("AMACT01300");
	SettingAMACT01300();

	//契約關卡關閉處理(A>05>1)
	//T-1
	OpenTabAndLogin(2);
	SetFuncNo("AMBDM04053");
	SettingAMBDM04053("B6011");
	OpenTabAndLogin(2);
	SetFuncNo("AMBDM04053");
	SettingAMBDM04053("B6019");
	OpenTabAndLogin(2);
	SetFuncNo("AMBDM04053");
	SettingAMBDM04053("B6020");

	//保管有價證券庫存帳值彙計表(R>0A>5)
	OpenTabAndLogin(2);
	SetFuncNo("AMRPT25004");
	SettingAMRPT25004();

	//189902會計科目彙總表(R>20>21)
	OpenTabAndLogin(2);
	SetFuncNo("AMRPT23001");

	//轉檔作業(M>01>3)
	OpenTabAndLogin(2);
	SetFuncNo("AMMET10011");
	SettingAMMET10011();

}

//開啟頁籤並登入
function OpenTabAndLogin(tabNum) {
	OpeTabs(tabNum);
	iimPlay("DisSystem/01.LoginDisSystem.iim");
}

//開啟新頁籤
function OpeTabs(tabNum) {
	var macro;
	macro = "CODE:";
	macro += "TAB OPEN" + "\n";
	macro += "TAB T=" + tabNum + "\n";
	iimPlay(macro);
}

//設定基金功能代號
function SetFuncNo(prgid) {
	var macro;
	macro = "CODE:";
	macro += "TAG POS=1 TYPE=INPUT:TEXT ATTR=ID:findProgId CONTENT=" + prgid + "\n";
	macro += "TAG POS=1 TYPE=BUTTON ATTR=ID:findProgBtn" + "\n";
	iimPlay(macro);
}

//"庫存及會計比對暨異常表列印(A>01>8)
//*處理項目：比對+列印"
function SettingAMACT01031() {
	var macro;
	macro = "CODE:";
	macro += "FRAME NAME=\"mainPanel\"" + "\n";
	macro += "TAG POS=1 TYPE=INPUT:RADIO FORM=ID:act01031 ATTR=NAME:criteria.prcsItem" + "\n";
	iimPlay(macro);
}

//設定AMRPT25004  保管種類
function SettingAMRPT25004() {
	var macro;
	macro = "CODE:";
	macro += "FRAME NAME=\"mainPanel\"" + "\n";
	macro += "TAG POS=1 TYPE=SELECT FORM=ID:frmRpt25004 ATTR=ID:entrustTyp CONTENT=%1" + "\n";
	iimPlay(macro);
}

//AMMET10011 轉檔作業(M>01>3)   *轉檔類別：2-轉出 轉檔項目：0030-保管有價證券餘額(189902)上傳作業
function SettingAMMET10011() {
	var macro;
	macro = "CODE:";
	macro += "FRAME NAME=\"mainPanel\"" + "\n";
	macro += "TAG POS=1 TYPE=SELECT FORM=ID:met01011 ATTR=ID:trnsfrFileCtg CONTENT=%2" + "\n";
	macro += "TAG POS=1 TYPE=SELECT FORM=ID:met01011 ATTR=ID:trnsfrFileItem CONTENT=%0030" + "\n";
	iimPlay(macro);
}

//AMACT01300  契約關卡關閉處理-整批 *關卡代碼：900  契約編號：B0000~B8000
function SettingAMACT01300() {
	var macro;
	macro = "CODE:";
	macro += "FRAME NAME=\"mainPanel\"" + "\n";
	macro += "TAG POS=1 TYPE=SELECT FORM=ID:frmAct01300 ATTR=ID:hrdlCde CONTENT=%900" + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:frmAct01300 ATTR=ID:contrNo_1 CONTENT=B0000" + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:frmAct01300 ATTR=ID:contrNo_2 CONTENT=B8000" + "\n";
	iimPlay(macro);
}

//AMBDM04053  契約關卡關閉處理 *關卡代碼：900  契約編號：B60XX
function SettingAMBDM04053(disNo) {
	var macro;
	macro = "CODE:";
	macro += "FRAME NAME=\"mainPanel\"" + "\n";
	macro += "TAG POS=1 TYPE=INPUT:TEXT FORM=ID:frmBdm04053 ATTR=ID:contrNo CONTENT=" + disNo + "\n";
	macro += "TAG POS=1 TYPE=SELECT FORM=ID:frmBdm04053 ATTR=ID:hrdlCdeList CONTENT=%900" + "\n";
	macro += "TAG POS=1 TYPE=BUTTON FORM=ID:frmBdm04053 ATTR=ID:btnBrw" + "\n";
	iimPlay(macro);
}
